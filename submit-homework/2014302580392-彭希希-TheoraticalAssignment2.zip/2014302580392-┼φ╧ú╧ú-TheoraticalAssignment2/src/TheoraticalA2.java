import org.eclipse.jface.action.MenuManager;
import org.eclipse.jface.action.StatusLineManager;
import org.eclipse.jface.action.ToolBarManager;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.window.ApplicationWindow;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Text;

public class TheoraticalA2 extends ApplicationWindow {
	private Composite composite;
	private Text text;
	private Text txtWelcome;
	private Text text_1;
	private double balance = 2333;
	private double money;
	private Text text_2;
	private Text text_3;
	private int i;

	/**
	 * Create the application window.
	 */
	public TheoraticalA2() {
		super(null);
		createActions();
		addToolBar(SWT.FLAT | SWT.WRAP);
		addMenuBar();
		addStatusLine();
	}

	/**
	 * Create contents of the application window.
	 * @param parent
	 */
	@Override
	protected Control createContents(Composite parent) {
		Composite container = new Composite(parent, SWT.NONE);
		
		Button button = new Button(container, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				i = 1;
				container.setVisible(false);
				composite.setVisible(true);
			}
		});
		button.setText("\u5B58\u6B3E");
		button.setBounds(68, 90, 80, 27);
		
		Button button_1 = new Button(container, SWT.NONE);
		button_1.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				i = 2;
				container.setVisible(false);
				composite.setVisible(true);
			}
		});
		button_1.setText("\u53D6\u6B3E");
		button_1.setBounds(68, 140, 80, 27);
		
		Button button_2 = new Button(container, SWT.NONE);
		button_2.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				System.exit(0);
			}
		});
		button_2.setText("\u9000\u51FA");
		button_2.setBounds(68, 190, 80, 27);
		
		text = new Text(container, SWT.READ_ONLY | SWT.CENTER);
		text.setText("\u4F59\u989D");
		text.setBounds(36, 51, 29, 17);
		
		txtWelcome = new Text(container, SWT.READ_ONLY | SWT.CENTER);
		txtWelcome.setText("Welcome!");
		txtWelcome.setBounds(0, 10, 224, 23);
		
		text_1 = new Text(container, SWT.BORDER | SWT.READ_ONLY);
		text_1.setBounds(71, 48, 106, 23);
		text_1.setText(Double.toString(balance));
		
		composite = new Composite(parent, SWT.NONE);
		composite.setBounds(1, 0, 223, 246);
		
		text_2 = new Text(composite, SWT.BORDER | SWT.CENTER);
		text_2.setLocation(58, 92);
		text_2.setSize(106, 23);
		
		text_3 = new Text(composite, SWT.READ_ONLY | SWT.CENTER);
		text_3.setText("\u8BF7\u8F93\u5165\u91D1\u989D\uFF1A");
		text_3.setBounds(0, 50, 223, 23);
		
		Button button_3 = new Button(composite, SWT.NONE);
		button_3.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				money = Double.parseDouble(text_2.getText());
				if(money <= 0)
				{
					MessageDialog.openError(Display.getCurrent().getActiveShell(), "error", "��������ȷ�Ľ��");
				}
				if(i == 1)
				{
					balance += money;
					container.setVisible(true);
					composite.setVisible(false);
				}
				if(i == 2)
				{
					if(money <= balance)
					{
						balance -= money;
						container.setVisible(true);
						composite.setVisible(false);
					}
					else
					{
						MessageDialog.openError(Display.getCurrent().getActiveShell(), "error", "����");
					}
				}
				text_1.setText(Double.toString(balance));
				text_2.setText("");
			}
		});
		button_3.setBounds(69, 143, 80, 27);
		button_3.setText("\u786E\u5B9A");
		
		Button button_4 = new Button(composite, SWT.NONE);
		button_4.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				container.setVisible(true);
				composite.setVisible(false);
			}
		});
		button_4.setText("\u53D6\u6D88");
		button_4.setBounds(69, 176, 80, 27);

		return container;
	}

	/**
	 * Create the actions.
	 */
	private void createActions() {
		// Create the actions
	}

	/**
	 * Create the menu manager.
	 * @return the menu manager
	 */
	@Override
	protected MenuManager createMenuManager() {
		MenuManager menuManager = new MenuManager("menu");
		return menuManager;
	}

	/**
	 * Create the toolbar manager.
	 * @return the toolbar manager
	 */
	@Override
	protected ToolBarManager createToolBarManager(int style) {
		ToolBarManager toolBarManager = new ToolBarManager(style);
		return toolBarManager;
	}

	/**
	 * Create the status line manager.
	 * @return the status line manager
	 */
	@Override
	protected StatusLineManager createStatusLineManager() {
		StatusLineManager statusLineManager = new StatusLineManager();
		return statusLineManager;
	}

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String args[]) {
		try {
			TheoraticalA2 window = new TheoraticalA2();
			window.setBlockOnOpen(true);
			window.open();
			Display.getCurrent().dispose();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Configure the shell.
	 * @param newShell
	 */
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("ATM");
	}

	/**
	 * Return the initial size of the window.
	 */
	@Override
	protected Point getInitialSize() {
		return new Point(240, 360);
	}
}
